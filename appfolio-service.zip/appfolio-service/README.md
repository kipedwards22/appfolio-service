# AppFolio Service

Python FastAPI microservice that wraps the AppFolio internal API.
Deployed on Railway alongside Chief of Staff and EG-Workorders.

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /health | Health check |
| GET | /tenants | Tenants (paginated) |
| GET | /tenants/all | All tenants |
| GET | /work-orders | Work orders by status |
| GET | /work-orders/all | All active work orders |
| GET | /delinquencies | Delinquency report |
| GET | /leases | Leases (paginated) |
| GET | /leases/expiring | Leases expiring in 90 days |
| GET | /properties | Properties |
| GET | /applications | Pending applications |
| GET | /vendors | Vendors |
| GET | /sync/all | Pull everything + format for CoS context sync |

All endpoints require header: `X-Service-Secret: <your-secret>`

## Auth: Refreshing Cookies

1. Log into evergreenmanagement.appfolio.com
2. F12 → Network → refresh page → click any request → Headers → copy Cookie value
3. Update APPFOLIO_COOKIES env var in Railway
4. Redeploy (Railway auto-redeploys on env var change)

## Wiring into Chief of Staff

Call /sync/all and POST the cos_payload to your CoS:

```bash
curl -X POST https://your-cos.railway.app/api/public/context/sync \
  -H "Authorization: Bearer cos_your_api_key" \
  -H "Content-Type: application/json" \
  -d '{ "title": "AppFolio Live Data", "category": "custom", "content": "..." }'
```

Set this up as a scheduled automation in Chief of Staff (every hour).

## Report Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /owners | List all owners with their AppFolio IDs |
| GET | /reports/owner-statement/{owner_id} | Owner statement for one owner |
| POST | /reports/owner-statement | Owner statement (POST with JSON body) |
| GET | /reports/rent-roll | Current rent roll |
| GET | /reports/all-owner-statements | All owners, all statements — CoS sync payload |
| GET | /analyze/owner/{owner_id} | Owner statement + Claude AI analysis |

## Example: Analyze one owner

```bash
curl "https://your-service.railway.app/analyze/owner/o_564?owner_name=Randy+Burr&date_from=03/01/2026&date_to=04/14/2026" \
  -H "X-Service-Secret: your-secret"
```

Returns plain-English summary + flagged issues + suggested owner response.

## Chief of Staff Integration

Ask your CoS: "How did Randy Burr's property do this month?"
CoS calls → /analyze/owner/o_564 → Claude reads the statement → returns summary
